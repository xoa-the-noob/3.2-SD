﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _170204048_offline2
{
    public partial class Purchases : Form
    {
        public Purchases()
        {
            InitializeComponent();
            customerName.Text = log_in.user;
            customerId.Text = log_in.pass;
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox3.Text) || String.IsNullOrEmpty(textBox4.Text) ||
            String.IsNullOrEmpty(textBox5.Text) || String.IsNullOrEmpty(textBox6.Text) ||
            String.IsNullOrEmpty(textBox7.Text) || String.IsNullOrEmpty(textBox8.Text) ||
            String.IsNullOrEmpty(textBox9.Text) || String.IsNullOrEmpty(textBox10.Text) ||
            String.IsNullOrEmpty(textBox11.Text) || String.IsNullOrEmpty(textBox12.Text))
            {
                MessageBox.Show("Pease fill out all fields");
            }
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox3.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 100))
                {
                    return;
                }
                if(number<0)
                {
                    MessageBox.Show("Invalid input");
                    textBox3.Clear();
                    textBox3.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Price cannot be more than 100");
                    textBox3.Clear();
                    textBox3.Select();
                }
              
            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox3.Clear();
                textBox3.Select();
            }
        }

        private void textBox5_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox5.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 100))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox5.Clear();
                    textBox5.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Price cannot be more than 100");
                    textBox5.Clear();
                    textBox5.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox5.Clear();
                textBox5.Select();
            }
        }

        private void textBox7_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox7.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 100))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox7.Clear();
                    textBox7.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Price cannot be more than 100");
                    textBox7.Clear();
                    textBox7.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox7.Clear();
                textBox7.Select();
            }
        }

        private void textBox9_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox9.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 100))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox9.Clear();
                    textBox9.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Price cannot be more than 100");
                    textBox9.Clear();
                    textBox9.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox9.Clear();
                textBox9.Select();
            }
        }

        private void textBox11_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox11.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 100))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox11.Clear();
                    textBox11.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Price cannot be more than 100");
                    textBox11.Clear();
                    textBox11.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox11.Clear();
                textBox11.Select();
            }
        }

        private void textBox4_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox4.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 10))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox4.Clear();
                    textBox4.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Amount cannot be more than 100");
                    textBox4.Clear();
                    textBox4.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox4.Clear();
                textBox4.Select();
            }
        }

        private void textBox6_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox6.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 10))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox6.Clear();
                    textBox6.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Amount cannot be more than 100");
                    textBox6.Clear();
                    textBox6.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox6.Clear();
                textBox6.Select();
            }
        }

        private void textBox8_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox8.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 10))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox8.Clear();
                    textBox8.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Amount cannot be more than 100");
                    textBox8.Clear();
                    textBox8.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox8.Clear();
                textBox8.Select();
            }
        }

        private void textBox10_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox10.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 10))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox10.Clear();
                    textBox10.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Amount cannot be more than 100");
                    textBox10.Clear();
                    textBox10.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox10.Clear();
                textBox10.Select();
            }
        }

        private void textBox12_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox12.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 10))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox12.Clear();
                    textBox12.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Amount cannot be more than 100");
                    textBox12.Clear();
                    textBox12.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox12.Clear();
                textBox12.Select();
            }
        }
    }
}
