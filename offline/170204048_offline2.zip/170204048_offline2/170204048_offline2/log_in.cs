﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _170204048_offline2
{
    public partial class log_in : Form
    {
        public static string user, pass;
        public log_in()
        {
            InitializeComponent();
            this.CenterToScreen();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(username.Text) && !String.IsNullOrEmpty(password.Text))
            {
                MessageBox.Show("Please enter username");
            }
            else if (String.IsNullOrEmpty(password.Text) && !String.IsNullOrEmpty(username.Text))
            {
                MessageBox.Show("Please enter password");
            }
            else if (String.IsNullOrEmpty(password.Text) && String.IsNullOrEmpty(username.Text))
            {
                MessageBox.Show("Please enter username and password");
            }
            else
            {
                if(username.Text == "Tahiya" && password.Text == "170204048")
                {
                    user = username.Text;
                    pass = password.Text;
                    Purchases p = new Purchases();
                    p.Show();
                    this.Visible = false;
                }
                else
                {
                    MessageBox.Show("Username and password doesn't match");
                    username.Clear();
                    password.Clear();
                    username.Select();
                }
                
            }
        }
    }
}
