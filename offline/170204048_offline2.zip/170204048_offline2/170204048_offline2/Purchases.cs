﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace _170204048_offline2
{
    public partial class Purchases : Form
    {
        public Purchases()
        {
            InitializeComponent();
            this.CenterToScreen();
            customerName.Text = log_in.user;
            customerId.Text = log_in.pass;

        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (String.IsNullOrEmpty(textBox3.Text) || String.IsNullOrEmpty(textBox4.Text) ||
            String.IsNullOrEmpty(textBox5.Text) || String.IsNullOrEmpty(textBox6.Text) ||
            String.IsNullOrEmpty(textBox7.Text) || String.IsNullOrEmpty(textBox8.Text) ||
            String.IsNullOrEmpty(textBox9.Text) || String.IsNullOrEmpty(textBox10.Text) ||
            String.IsNullOrEmpty(textBox11.Text) || String.IsNullOrEmpty(textBox12.Text))
            {
                MessageBox.Show("Pease fill out all fields");
            }
            else
            {
                int a1 = Int32.Parse(textBox3.Text);
                int a2 = Int32.Parse(textBox5.Text);
                int a3 = Int32.Parse(textBox7.Text);
                int a4 = Int32.Parse(textBox9.Text);
                int a5 = Int32.Parse(textBox11.Text);

                int p1 = Int32.Parse(textBox4.Text);
                int p2 = Int32.Parse(textBox6.Text);
                int p3 = Int32.Parse(textBox8.Text);
                int p4 = Int32.Parse(textBox10.Text);
                int p5 = Int32.Parse(textBox12.Text);

                int sum = a1 * p1 + a2 * p2 + a3 * p3 + a4 * p4 + a5 * p5;
                
                double temp;
                
                if(sum <= 1000)
                {
                    temp = sum;
                    String total = temp.ToString();
                    totalPrice.Text = total;
                }
                else if (sum > 1000 && sum < 2000)
                {
                    temp = sum + 0.05*sum;
                    String total = temp.ToString();
                    totalPrice.Text = total;
                }
                else if (sum >= 2000 && sum < 3500)
                {
                    temp = sum + 0.1 * sum;
                    String total = temp.ToString();
                    totalPrice.Text = total;
                }
                if (sum >= 3500)
                {
                    temp = sum + 0.15 * sum;
                    String total = temp.ToString();
                    totalPrice.Text = total;
                }

            }
        }

        private void textBox3_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox3.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 100))
                {
                    return;
                }
                if(number<0)
                {
                    MessageBox.Show("Invalid input");
                    textBox3.Clear();
                    textBox3.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Price cannot be more than 100");
                    textBox3.Clear();
                    textBox3.Select();
                }
              
            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox3.Clear();
                textBox3.Select();
            }
        }

        private void textBox5_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox5.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 100))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox5.Clear();
                    textBox5.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Price cannot be more than 100");
                    textBox5.Clear();
                    textBox5.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox5.Clear();
                textBox5.Select();
            }
        }

        private void textBox7_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox7.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 100))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox7.Clear();
                    textBox7.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Price cannot be more than 100");
                    textBox7.Clear();
                    textBox7.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox7.Clear();
                textBox7.Select();
            }
        }

        private void textBox9_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox9.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 100))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox9.Clear();
                    textBox9.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Price cannot be more than 100");
                    textBox9.Clear();
                    textBox9.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox9.Clear();
                textBox9.Select();
            }
        }

        private void textBox11_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox11.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 100))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox11.Clear();
                    textBox11.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Price cannot be more than 100");
                    textBox11.Clear();
                    textBox11.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox11.Clear();
                textBox11.Select();
            }
        }

        private void textBox4_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox4.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 10))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox4.Clear();
                    textBox4.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Amount cannot be more than 100");
                    textBox4.Clear();
                    textBox4.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox4.Clear();
                textBox4.Select();
            }
        }

        private void textBox6_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox6.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 10))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox6.Clear();
                    textBox6.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Amount cannot be more than 100");
                    textBox6.Clear();
                    textBox6.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox6.Clear();
                textBox6.Select();
            }
        }

        private void textBox8_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox8.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 10))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox8.Clear();
                    textBox8.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Amount cannot be more than 100");
                    textBox8.Clear();
                    textBox8.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox8.Clear();
                textBox8.Select();
            }
        }

        private void textBox10_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox10.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 10))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox10.Clear();
                    textBox10.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Amount cannot be more than 100");
                    textBox10.Clear();
                    textBox10.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox10.Clear();
                textBox10.Select();
            }
        }

        private void textBox12_Validating(object sender, CancelEventArgs e)
        {
            string numberStr = textBox12.Text;
            if (String.IsNullOrEmpty(numberStr)) { return; }
            int number;

            bool isParsable = Int32.TryParse(numberStr, out number);

            if (isParsable)
            {
                if ((number >= 0 && number <= 10))
                {
                    return;
                }
                if (number < 0)
                {
                    MessageBox.Show("Invalid input");
                    textBox12.Clear();
                    textBox12.Select();
                }
                if (number > 100)
                {
                    MessageBox.Show("Amount cannot be more than 100");
                    textBox12.Clear();
                    textBox12.Select();
                }

            }
            else
            {
                MessageBox.Show("Invalid input");
                textBox12.Clear();
                textBox12.Select();
            }
        }
    }
}
